package bank;

public interface CalculateBill {
     double calculate();
}
